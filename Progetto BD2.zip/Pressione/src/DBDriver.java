import java.util.ArrayList;
import java.util.regex.Pattern;

import com.mongodb.*;

public class DBDriver {
	private static DBDriver instance = new DBDriver();
	private DB db;
	
	private DBDriver() {
		MongoClient client = new MongoClient("localhost",27017);
		db = client.getDB("Progetto");
	}
	
	public static DBDriver getInstance() {
		return instance;
	}
	
	public ArrayList<String> getComuni(String provincia) {
		ArrayList<String> result;
		BasicDBObject filter = new BasicDBObject("Provincia",provincia);
		result = (ArrayList<String>) db.getCollection("Strutture").distinct("Comune",filter);
		java.util.Collections.sort(result);
		return result;
	}
	
	public ArrayList<String> getProvince(){
		ArrayList<String> result;
		result = (ArrayList<String>) db.getCollection("Strutture").distinct("Provincia");
		java.util.Collections.sort(result);
		return result;
	}
	
	public ArrayList<String> getTipologie(){
		ArrayList<String> result;
		result = (ArrayList<String>) db.getCollection("Strutture").distinct("Tipologia");
		java.util.Collections.sort(result);
		return result;
	}
	
	public ArrayList<Struttura> queryDB(String nome,String indirizzo,String provincia,String comune,String tipologia,String stelle,String piscina,String disabili,String parcheggio,String aria,String animali){
		ArrayList<Struttura> result = new ArrayList<>();
		BasicDBObject filter = new BasicDBObject();
		if(!nome.equals("Nome"))
			filter.put("Denominazione", Pattern.compile(nome, Pattern.CASE_INSENSITIVE) );
		if(!indirizzo.equals("Indirizzo")) 
			filter.put("Indirizzo", Pattern.compile(indirizzo, Pattern.CASE_INSENSITIVE) );
		
		if(!provincia.equals("TUTTE")) 
			filter.put("Provincia", Pattern.compile(provincia, Pattern.CASE_INSENSITIVE) );
		
		if(!comune.equals("TUTTI"))
			filter.put("Comune", Pattern.compile(comune, Pattern.CASE_INSENSITIVE) );
		if(!tipologia.equals("TUTTE"))
			filter.put("Tipologia", Pattern.compile(tipologia, Pattern.CASE_INSENSITIVE) );
		if(!stelle.equals(""))
			filter.put("Stelle", stelle );
		if(!piscina.equals(""))
			filter.put("Piscina", Pattern.compile(piscina, Pattern.CASE_INSENSITIVE) );
		if(!disabili.equals(""))
			filter.put("Accesso ai disabili", Pattern.compile(disabili, Pattern.CASE_INSENSITIVE) );
		if(!parcheggio.equals(""))
			filter.put("Parcheggio", Pattern.compile(parcheggio, Pattern.CASE_INSENSITIVE) );
		if(!aria.equals(""))
			filter.put("Aria condizionata", Pattern.compile(aria, Pattern.CASE_INSENSITIVE) );
		if(!animali.equals(""))
			filter.put("Animali ammessi", Pattern.compile(animali, Pattern.CASE_INSENSITIVE) );
		
		DBCursor cursor = db.getCollection("Strutture").find(filter);
		while(cursor.hasNext()) {
			DBObject o = cursor.next();
			String currentNome = (o.get("Denominazione") == null) ? "" : o.get("Denominazione").toString();
			String currentIndirizzo = (o.get("Indirizzo") == null) ? "" : o.get("Indirizzo").toString();
			String currentComune = (o.get("Comune") == null) ? "" : o.get("Comune").toString();
			String currentProvincia = (o.get("Provincia") == null) ? "" : o.get("Provincia").toString();
			String currentTipologia = (o.get("Tipologia") == null) ? "" : o.get("Tipologia").toString();
			String currentStelle = (o.get("Stelle") == null) ? "" : o.get("Stelle").toString();
			String currentTelefono = (o.get("Telefono") == null) ? "" : o.get("Telefono").toString();
			String currentSito = (o.get("Sito internet") == null) ? "" : o.get("Sito internet").toString();
			Struttura s = new Struttura(currentNome,currentComune,currentProvincia,currentIndirizzo,currentTipologia,currentStelle,currentTelefono,currentSito);
			result.add(s);
		}
			
		return result;
	}
	
}
