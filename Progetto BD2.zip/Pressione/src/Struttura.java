public class Struttura {
  private String nome;
  private String comune;
  private String provincia;
  private String indirizzo;
  private String tipologia;
  private String stelle;
  private String telefono;
  private String sito;
  
  
  public Struttura(String nome, String comune, String provincia, String indirizzo, String tipologia, String stelle,
      String telefono, String sito) {
    super();
    this.nome = nome;
    this.comune = comune;
    this.provincia = provincia;
    this.indirizzo = indirizzo;
    this.tipologia = tipologia;
    this.stelle = stelle;
    this.telefono = telefono;
    this.sito = sito;
  }
  public String getNome() {
    return nome;
  }
  public void setNome(String nome) {
    this.nome = nome;
  }
  public String getComune() {
    return comune;
  }
  public void setComune(String comune) {
    this.comune = comune;
  }
  public String getProvincia() {
    return provincia;
  }
  public void setProvincia(String provincia) {
    this.provincia = provincia;
  }
  public String getIndirizzo() {
    return indirizzo;
  }
  public void setIndirizzo(String indirizzo) {
    this.indirizzo = indirizzo;
  }
  public String getTipologia() {
    return tipologia;
  }
  public void setTipologia(String tipologia) {
    this.tipologia = tipologia;
  }
  public String getStelle() {
    return stelle;
  }
  public void setStelle(String stelle) {
    this.stelle = stelle;
  }
  public String getTelefono() {
    return telefono;
  }
  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }
  public String getSito() {
    return sito;
  }
  public void setSito(String sito) {
    this.sito = sito;
  }
  
  @Override
  
  public String toString() {
    String result = "Nome : " + nome + " Comune : " + comune + " Indirizzo : " + indirizzo + " Provincia : " + provincia + " Tipologia : " + tipologia + " Stelle : " + stelle + " Telefono : " + telefono + " Web : " + sito;
    return result;
  }

}
